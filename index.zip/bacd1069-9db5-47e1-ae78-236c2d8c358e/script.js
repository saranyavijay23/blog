document.addEventListener("DOMContentLoaded", function() {
  const navMenu = document.getElementById('navMenu');
  const navToggle = document.getElementById('navToggle');

  // Toggle navigation menu on small screens
  navToggle.addEventListener('click', function() {
    const ul = navMenu.querySelector('ul');
if(u1.style.display==='block')
{
u1.style.display = 'none';
}
else
{

    ul.style.display = 'block';
}
  });
});